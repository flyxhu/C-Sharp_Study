﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _023ForXunhuan
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int index=1;index<=9;index++)//初始化的值，取值范围，循环体运算
            {
                Console.WriteLine(index);
            }
            Console.ReadKey();

        }
    }
}
